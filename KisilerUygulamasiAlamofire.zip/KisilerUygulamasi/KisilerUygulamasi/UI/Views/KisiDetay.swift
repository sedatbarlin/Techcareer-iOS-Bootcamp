//
//  KisiDetay.swift
//  KisilerUygulamasi
//
//  Created by Sedat on 4.12.2023.
//

import UIKit

class KisiDetay: UIViewController {
    
    @IBOutlet weak var kisiAdTextField: UITextField!
    @IBOutlet weak var kisiTelTextField: UITextField!
    
    var kisi:Kisiler?
    var viewModel = KisiDetayViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let k = kisi{
            kisiAdTextField.text = k.kisi_ad
            kisiTelTextField.text = k.kisi_tel
        }
        
    }
    @IBAction func guncelleButton(_ sender: Any) {
        if let ad = kisiAdTextField.text, let tel = kisiTelTextField.text, let k = kisi{
            viewModel.guncelle(kisi_id: Int(k.kisi_id!)!, kisi_ad: ad, kisi_tel: tel)
        }
    }
}
