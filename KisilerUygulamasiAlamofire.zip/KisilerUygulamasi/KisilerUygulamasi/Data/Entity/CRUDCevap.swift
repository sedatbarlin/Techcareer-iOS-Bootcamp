//
//  CRUDCevap.swift
//  KisilerUygulamasi
//
//  Created by Sedat on 14.12.2023.
//

import Foundation

class CRUDCevap: Codable{
    var success: Int?
    var message: String?
}
