//
//  KisilerCevap.swift
//  KisilerUygulamasi
//
//  Created by Sedat on 14.12.2023.
//

import Foundation

class KisilerCevap: Codable{ //Json formatındaki tabloları alabilsin diye codable
    var kisiler: [Kisiler]?
    var success: Int?
}
