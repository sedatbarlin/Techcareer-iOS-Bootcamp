//
//  KisilerHucre.swift
//  KisilerUygulamasi
//
//  Created by Sedat on 4.12.2023.
//

import UIKit

class KisilerHucre: UITableViewCell {
    
    @IBOutlet weak var kisiAdLabel: UILabel!
    @IBOutlet weak var kisiTelLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
