//
//  FoodsDaoRepository.swift
//  Foodie
//
//  Created by Sedat on 15.12.2023.
//

import Foundation
import RxSwift
import Alamofire
import UIKit
import FirebaseFirestore
import FirebaseAuth

class FoodsDaoRepository {
    var foodList = BehaviorSubject<[Foods]>(value: [Foods]())
    var cartFoodsList = BehaviorSubject<[CartFoods]>(value: [CartFoods]())
    var totalPrice = BehaviorSubject<Int>(value: Int())
    
    func loadFoods() {
        AF.request("http://kasimadalan.pe.hu/yemekler/tumYemekleriGetir.php", method: .get).response { response in
            if let data = response.data {
                do{
                    let response = try JSONDecoder().decode(FoodsResponse.self, from: data)
                    if let list = response.yemekler {
                        self.foodList.onNext(list)
                    }
                }catch{
                    print(error.localizedDescription)
                }
            }
        }
    }
    
    func addCart(yemek_adi: String, yemek_resim_adi: String, yemek_fiyat: Int, yemek_siparis_adet: Int, kullanici_adi: String, completion: @escaping (Bool) ->Void) {
        var piece = 0
        bringCartFoods(kullanici_adi: kullanici_adi) { foods, error  in
            if error != nil {
                piece = yemek_siparis_adet
                let params: Parameters = ["yemek_adi": yemek_adi, "yemek_resim_adi": yemek_resim_adi, "yemek_fiyat": yemek_fiyat, "yemek_siparis_adet": piece, "kullanici_adi": kullanici_adi]
                AF.request("http://kasimadalan.pe.hu/yemekler/sepeteYemekEkle.php", method: .post, parameters: params).response { response in
                    if let data = response.data {
                        do {
                            let response = try JSONDecoder().decode(CartResponse.self, from: data)
                            if response.success == 0 {
                                completion(false)
                            } else {
                                completion(true)
                            }
                            
                        } catch {
                            print(error.localizedDescription)
                        }
                    }
                }
            } else {
                if let foodss = foods {
                    for food in foodss {
                        if food.yemek_adi == yemek_adi {
                            piece = Int(food.yemek_siparis_adet)! + yemek_siparis_adet
                            self.deleteFoods(sepet_yemek_id: Int(food.sepet_yemek_id!)!, kullanici_adi: food.kullanici_adi)
                            break
                        } else {
                            piece = yemek_siparis_adet
                        }
                    }
                }
                
                let params: Parameters = ["yemek_adi": yemek_adi, "yemek_resim_adi": yemek_resim_adi, "yemek_fiyat": yemek_fiyat, "yemek_siparis_adet": piece, "kullanici_adi": kullanici_adi]
                AF.request("http://kasimadalan.pe.hu/yemekler/sepeteYemekEkle.php", method: .post, parameters: params).response { reponse in
                    if let data = reponse.data {
                        do {
                            let response = try JSONDecoder().decode(CartResponse.self, from: data)
                            if response.success == 0 {
                                completion(false)
                            } else {
                                completion(true)
                            }
                        } catch {
                            print(error.localizedDescription)
                        }
                    }
                }
            }
        }
    }
    
    func deleteFoods(sepet_yemek_id: Int, kullanici_adi: String) {
        let params: Parameters = ["sepet_yemek_id": sepet_yemek_id, "kullanici_adi": kullanici_adi]
        AF.request("http://kasimadalan.pe.hu/yemekler/sepettenYemekSil.php",method: .post,parameters: params).response { response in
            if let data = response.data {
                do{
                    let myAnswer = try JSONDecoder().decode(CartResponse.self, from: data)
                    self.bringCartFoods(kullanici_adi: kullanici_adi) { _ , error in
                        if error != nil {
                            self.totalPrice.onNext(0)
                        } else {
                        }
                    }
                }catch{
                    print(error.localizedDescription)
                }
            }
        }
    }
    
    func bringCartFoods(kullanici_adi: String) {
        var amount = 0
        let params: Parameters = ["kullanici_adi": kullanici_adi]
        AF.request("http://kasimadalan.pe.hu/yemekler/sepettekiYemekleriGetir.php", method: .post, parameters: params).response { response in
            if let data = response.data {
                do {
                    let response = try JSONDecoder().decode(CartFoodsResponse.self, from: data)
                    if let list = response.sepet_yemekler {
                        self.cartFoodsList.onNext(list)
                        for food in list {
                            amount += Int(food.yemek_siparis_adet)! * Int(food.yemek_fiyat)!
                            self.totalPrice.onNext(amount)
                        }
                    }
                } catch {
                    print(error.localizedDescription)
                }
            }
        }
    }
    
    func searchFoods(aramaKelimesi:String){
        var searchFoods = [Foods]()
        if aramaKelimesi != "" {
            AF.request("http://kasimadalan.pe.hu/yemekler/tumYemekleriGetir.php", method: .get).response { response in
                if let data = response.data {
                    do{
                        let response = try JSONDecoder().decode(FoodsResponse.self, from: data)
                        if let list = response.yemekler {
                            for foods in list {
                                if foods.yemek_adi.contains(aramaKelimesi) {
                                    searchFoods.append(foods)
                                }
                            }
                            self.foodList.onNext(searchFoods)
                        }
                    }catch{
                        print(error.localizedDescription)
                    }
                }
            }
        } else {
            loadFoods()
        }
    }
    
    func signUp(email: String?, password: String?, completion: @escaping (Bool) -> Void) {
        if let mail = email, let password = password {
            let user = Users(email: mail, password: password)
            let data = ["email": user.email, "password": user.password]
            Auth.auth().createUser(withEmail: mail, password: password) { authResult, error in
                if error == nil {
                    let myUsers = Firestore.firestore()
                    let userCollection = myUsers.collection("Users").document(authResult?.user.uid ?? "").collection(user.email)
                    userCollection.document("UserInfo").setData(data) { error in
                        if error != nil {
                            completion(false)
                        } else {
                            completion(true)
                        }
                    }
                } else {
                    completion(false)
                }
            }
        }
    }
    
    func signIn(email: String, password: String, completion: @escaping (Error?) -> Void) {
        Auth.auth().signIn(withEmail: email, password: password) { _ , error in
            if let error = error {
                completion(error)
            } else {
                completion(nil)
            }
        }
    }
    
    func categorizedList(listContens: [String]) {
        AF.request("http://kasimadalan.pe.hu/yemekler/tumYemekleriGetir.php", method: .get).response { response in
            if let data = response.data {
                do {
                    let response = try JSONDecoder().decode(FoodsResponse.self, from: data)
                    if let list = response.yemekler {
                        let filteredList = list.filter { food in
                            return listContens.contains(food.yemek_id)
                        }
                        self.foodList.onNext(filteredList)
                    }
                } catch {
                    print(error.localizedDescription)
                }
            }
        }
    }
    
    func bringCartFoods(kullanici_adi: String, completion: @escaping([CartFoods]?, Error?) -> Void) {
        var amount = 0
        let params: Parameters = ["kullanici_adi": kullanici_adi]
        AF.request("http://kasimadalan.pe.hu/yemekler/sepettekiYemekleriGetir.php", method: .post, parameters: params).response { response in
            if let data = response.data {
                do {
                    let response = try JSONDecoder().decode(CartFoodsResponse.self, from: data)
                    if let list = response.sepet_yemekler {
                        self.cartFoodsList.onNext(list)
                        for food in list {
                            amount += Int(food.yemek_siparis_adet)! * Int(food.yemek_fiyat)!
                            self.totalPrice.onNext(amount)
                        }
                        completion(list, nil)
                    }
                } catch {
                    print(error.localizedDescription)
                    completion(nil, error)
                }
            }
        }
    }
    
    func fetchUserData(completion: @escaping (Users) -> Void) {
        let myUsers = Firestore.firestore()
        if let user = Auth.auth().currentUser {
            let userCollection = myUsers.collection("Users").document(user.uid).collection(user.email!).document("UserInfo")
            userCollection.getDocument { (document, error) in
                if let document = document, document.exists {
                    if let userData = document.data() {
                        if let email = userData["email"] as? String, let password = userData["password"] as? String {
                            let user = Users(email: email, password: password)
                            completion(user)
                        }
                    }
                } else {
                    print(error?.localizedDescription as Any)
                }
            }
        }
    }
}
