//
//  CRUDResponse.swift
//  Foodie
//
//  Created by Sedat on 15.12.2023.
//

import Foundation

class CartResponse: Codable{
    var success: Int?
    var message: String?
}
