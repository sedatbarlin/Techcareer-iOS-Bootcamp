//
//  CartFoodsResponse.swift
//  Foodie
//
//  Created by Sedat on 15.12.2023.
//

import Foundation

class CartFoodsResponse: Codable{
    var sepet_yemekler : [CartFoods]?
    var success: Int?
}
