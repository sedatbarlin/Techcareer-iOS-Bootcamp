//
//  ProfileViewModel.swift
//  Foodie
//
//  Created by Sedat on 18.12.2023.
//

import Foundation
import FirebaseAuth

class ProfileViewModel {
    var userItems: [String] = [
        "Profil Bilgileri","Bildirim Ayarları","Gizlilik ve Güvenlik","Ödeme Yöntemleri","Sipariş Geçmişi","Çıkış Yap"
    ]
    
    func signOut(completion: @escaping (Error?) -> Void) {
        do {
            try Auth.auth().signOut()
            completion(nil)
        } catch let error as NSError {
            completion(error)
        }
    }
    
    func bringUserName() -> String? {
        if let bringUserName = Auth.auth().currentUser?.email {
            let components = bringUserName.components(separatedBy: "@")
            if components.count == 2 {
                var username = components[0]
                username = username.prefix(1).capitalized + username.dropFirst()
                return username
            }
        }
        return nil
    }
}
