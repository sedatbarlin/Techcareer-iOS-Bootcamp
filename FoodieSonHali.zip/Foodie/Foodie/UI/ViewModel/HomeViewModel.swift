//
//  HomeViewModel.swift
//  Foodie
//
//  Created by Sedat on 15.12.2023.
//

import Foundation
import RxSwift
import UIKit

class HomeViewModel{
    let repository = FoodsDaoRepository()
    var foodList = BehaviorSubject<[Foods]>(value: [Foods]())
    var orderQuantity   = BehaviorSubject<Int>(value: 1)
    var cartFoodList = BehaviorSubject<[CartFoods]>(value: [CartFoods]())
    
    let drinks = ["1", "3", "7", "12"]
    let deserts = ["2", "6", "14"]
    let meals = ["4", "5","8","9","10","11", "13"]
    
    init() {
        foodList = repository.foodList
    }
    
    func loadFoods() {
        repository.loadFoods()
    }
    
    func searchFoods(aramaKelimesi: String) {
        repository.searchFoods(aramaKelimesi: aramaKelimesi)
    }
    
    func segmentedFoodList(idList: [String]){
        repository.categorizedList(listContens: idList)
    }
    func uploadFoods(){
        repository.loadFoods()
    }
}
