//
//  ProfileViewController.swift
//  Foodie
//
//  Created by Sedat on 15.12.2023.
//

import UIKit
import FirebaseAuth

class ProfileViewController: UIViewController {
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var nameLabel: UILabel!
    let viewModel = ProfileViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
        if let username = viewModel.bringUserName() {
            nameLabel.text = "Merhaba " + username
        }
    }
    private func errorAlert(message: String) {
        let alert = UIAlertController(title: "ERROR!", message: message, preferredStyle: .alert)
        let okeyAction = UIAlertAction(title: "Tamam", style: .default, handler: nil)
        alert.addAction(okeyAction)
        present(alert, animated: true, completion: nil)
    }
    func logOutOfAccount() {
        let alert = UIAlertController(title: "Çıkış Yap", message: "Çıkış yapmak üzeresiniz. Emin misiniz?", preferredStyle: .alert)
        let cancelAction = UIAlertAction(title: "İptal", style: .default, handler: nil)
        let logOutAction = UIAlertAction(title: "Çıkış Yap", style: .destructive) { _ in self.viewModel.signOut { [weak self] error in
            if let error = error {
                self?.errorAlert(message: "Hesaptan çıkış yapılamadı! \(error.localizedDescription)")
            } else {
                let controller = self?.storyboard?.instantiateViewController(withIdentifier: "SignInViewController") as! SignInViewController
                controller.modalPresentationStyle = .fullScreen
                controller.modalTransitionStyle = .partialCurl
                self?.present(controller, animated: true, completion: nil)
            }
        }
        }
        alert.addAction(cancelAction)
        alert.addAction(logOutAction)
        present(alert, animated: true, completion: nil)
    }
}




