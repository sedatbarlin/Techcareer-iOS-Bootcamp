//
//  CartViewController.swift
//  Foodie
//
//  Created by Sedat on 15.12.2023.
//

import UIKit
import RxSwift

class CartViewController: UIViewController {
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var toplamLabel: UILabel!
    let viewModel = CartViewModel()
    var foodList = [CartFoods]()
    var totalPrice = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        _ = viewModel.foodList.subscribe(onNext: { list in
            self.foodList = list
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        })
        _ = viewModel.totalPrice.subscribe(onNext: { total in
            self.totalPrice = total
            DispatchQueue.main.async {
                self.toplamLabel.text = "\(String(self.totalPrice)) ₺"
            }
        })
    }
    override func viewWillAppear(_ animated: Bool) {
        viewModel.bringCartFoods(kullanici_adi: "resedat")
    }
    
    @IBAction func satinAlPressed(_ sender: UIButton) {
        let alert = UIAlertController(title: "Satın Alma", message: "Ürünler başarıyla sipariş verildi. En kısa sürede kuryemiz tarafından aranacaksınız, iyi günler.", preferredStyle: .alert)
        let okeyAction = UIAlertAction(title: "Tamam", style: .cancel){ _ in
            let controller = self.storyboard?.instantiateViewController(withIdentifier: "CustomTabBarViewController") as! CustomTabBarViewController
            controller.modalPresentationStyle = .fullScreen
            controller.modalTransitionStyle = .flipHorizontal
            self.present(controller, animated: true, completion: nil)
        }
        alert.addAction(okeyAction)
        self.present(alert, animated: true)
    }
}
