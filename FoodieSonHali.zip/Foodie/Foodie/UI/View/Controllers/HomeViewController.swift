//
//  HomeViewController.swift
//  Foodie
//
//  Created by Sedat on 15.12.2023.
//

import UIKit
import Kingfisher

class HomeViewController: UIViewController{
    
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var segmentedControl: UISegmentedControl!
    @IBOutlet weak var collectionView: UICollectionView!
    
    let viewModel = HomeViewModel()
    let detailViewModel = FoodDetailViewModel()
    var foodList = [Foods]()
    var collectionViewCell = FoodsCollectionViewCell()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        collectionView.dataSource = self
        collectionView.delegate = self
        searchBar.delegate = self
        collectionViewCell.cartButton?.tintColor = UIColor(red: 113/255, green: 156/255, blue: 111/255, alpha: 1)
        
        _ = viewModel.foodList.subscribe(onNext: { list in
            self.foodList = list
            DispatchQueue.main.async {
                self.collectionView.reloadData()
            }
        })
        
        let collectionDesign = UICollectionViewFlowLayout()
        collectionDesign.sectionInset = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        collectionDesign.minimumLineSpacing = 10
        collectionDesign.minimumInteritemSpacing = 10
        
        let screenWidth = UIScreen.main.bounds.width
        let cellWidth = (screenWidth - 40) / 2
        
        collectionDesign.itemSize = CGSize(width: cellWidth, height: cellWidth * 1.6)
        collectionView.collectionViewLayout = collectionDesign
    }
    
    override func viewWillAppear(_ animated: Bool) {
        viewModel.loadFoods()
        segmentedControl.selectedSegmentIndex = 0
        collectionViewCell.cartButton?.tintColor = UIColor(red: 113/255, green: 156/255, blue: 111/255, alpha: 1)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toDetay" {
            if let yemek = sender as? Foods {
                let goToViewController = segue.destination as! FoodDetailViewController
                goToViewController.food = yemek
            }
        }
    }
    
    @IBAction func categoryControl(_ sender: UISegmentedControl) {
        let selectedIndex = sender.selectedSegmentIndex
        switch selectedIndex{
        case 0: viewModel.loadFoods()
        case 1: viewModel.segmentedFoodList(idList: viewModel.meals)
        case 2: viewModel.segmentedFoodList(idList: viewModel.deserts)
        case 3: viewModel.segmentedFoodList(idList: viewModel.drinks)
        default:
            break
        }
    }
}
