//
//  KisiKayit.swift
//  KisilerUygulamasi
//
//  Created by Sedat on 4.12.2023.
//

import UIKit

class KisiKayit: UIViewController {
    
    @IBOutlet weak var kisiAdTextField: UITextField!
    @IBOutlet weak var kisiTelTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    
    @IBAction func kaydetButton(_ sender: Any) {
        if let ad = kisiAdTextField.text, let tel  = kisiTelTextField.text{
            kaydet(kisi_ad: ad, kisi_tel: tel)
        }
    }
    
    func kaydet(kisi_ad:String, kisi_tel:String){
        print("Kişi Kaydet: \(kisi_ad) - \(kisi_tel)")
    }
    
}
